# HealthyLifeTracker
Healthy Life Tracker is a user-friendly Hebrew website designed to help people monitor and improve their health by offering exercise recommendations, fitness videos, and a BMI calculator
